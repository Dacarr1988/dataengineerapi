
CREATE TABLE IF NOT EXISTS `reviews` (
  `province` text,
  `region_2` text,
  `description` text,
  `designation` text,
  `title` text,
  `region_1` text,
  `country` text,
  `taster_name` text,
  `variety` text,
  `points` int DEFAULT NULL,
  `winery` text,
  `price` float DEFAULT NULL,
  `taster_twitter_handle` text
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS `userinfo` (
  `id_str` text,
  `screen_name` text,
  `name` text,
  `description` text,
  `profile_image_url_https` text,
  `followers_count` int DEFAULT NULL
) ENGINE=InnoDB;