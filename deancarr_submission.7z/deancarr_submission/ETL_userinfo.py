import MySQLdb as db
import pandas as pd
import numpy as np
import tweepy as tw


#Script Variables
db_server="localhost"
db_name="vino"
db_user="vino"
db_pwd="vino"
consumer_key=""
consumer_secret=""
access_token=""
access_token_secret=""


#Step 1: Connect to database
print("Step 1: Connect to database")
con = db.connect(db_server, db_user, db_pwd, db_name, use_unicode=True, charset="utf8")
cur = con.cursor()


#Step 2: Get taster twitter handles
print("Step 2: Get taster twitter handles")
sql = """select taster_twitter_handle
            from reviews
            where taster_twitter_handle is not null
            group by taster_twitter_handle;"""
cur.execute(sql)
rs = cur.fetchall()


#Step 3: Run any transforms
df = pd.DataFrame(rs, columns =['taster_twitter_handle']) #convert list to dataframe
df = df['taster_twitter_handle'].str.strip() #remove any trailing spaces


#Close database connection
print("Close database connection")
con.close()


#Connect to Twitter api
print("Connect to Twitter api")
auth = tw.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tw.API(auth)


#Get Twitter user data
print("Get Twitter user data")
usersdf = pd.DataFrame(columns=['id_str', \
                                'screen_name', \
                                'name', \
                                'description', \
                                'profile_image_url_https', \
                                'followers_count'])
for row in rs:
    try:
        user = api.get_user(row[0])
        usersdf = usersdf.append({'id_str': user.id_str, \
                                 'screen_name': user.screen_name, \
                                 'name': user.name, \
                                 'description': user.description, \
                                 'profile_image_url_https': user.profile_image_url_https, \
                                 'followers_count': user.followers_count}, \
                                 ignore_index=True)
    except:
        pass


#Connect to database
print("Connect to database")
con = db.connect(db_server, db_user, db_pwd, db_name, use_unicode=True, charset="utf8")
cur = con.cursor()


#Load data into database
print("Load data into database")
sql = "INSERT INTO userinfo (id_str, \
                            screen_name, \
                            name, \
                            description, \
                            profile_image_url_https, \
                            followers_count) \
                        VALUES (%s, %s, %s, %s, %s, %s)"
cur.executemany(sql, usersdf.values.tolist())
con.commit()


#Print row count
print('Row Count: %d' % cur.rowcount)


#Close database connection
print("Close database connection")
con.close()
