import MySQLdb as db
import pandas as pd
import numpy as np


#Script Variables
filename='...winemag-data-130k-v2-formatted.json'
db_server="localhost"
db_name="vino"
db_user="vino"
db_pwd="vino"


#Step 1: Extract data from file
print("Step 1: Extract data from file")
df = pd.read_json(filename)


#Step 2: Run Transforms
print("Step 2: Run Transforms")
df = df.replace({np.nan: None}) #Retain null values for dataset originality


#Step 3: Connect to database
print("Step 3: Connect to database")
con = db.connect(db_server, db_user, db_pwd, db_name, use_unicode=True, charset="utf8")
cur = con.cursor()


#Step 4: Load data into database
print("Step 4: Load data into database")
sql = "INSERT INTO " + db_name + ".reviews (points, \
                                    title, \
                                    description, \
                                    taster_name, \
                                    taster_twitter_handle, \
                                    price, \
                                    designation, \
                                    variety, \
                                    region_1, \
                                    region_2, \
                                    province, \
                                    country, \
                                    winery) \
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
cur.executemany(sql, df.values.tolist())
con.commit()


#Print row count
print('Row Count: %d' % cur.rowcount)


#Close database connection
print("Close database connection")
con.close()
