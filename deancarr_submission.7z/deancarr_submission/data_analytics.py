import MySQLdb as db
import pandas as pd
import numpy as np


#Script Variables
db_server="localhost"
db_name="vino"
db_user="vino"
db_pwd="vino"


#Step 1: Connect to database
print("Step 1: Connect to database")
con = db.connect(db_server, db_user, db_pwd, db_name, use_unicode=True, charset="utf8")
cur = con.cursor()


#Step 2: Unique Reviewers Query
#Write a script that counts the number of unique reviewers in the reviews table.
print("Step 2: Unique Reviewers Query")
sql = """select count(*) as unique_reviewers_count
                from
                (
                        select ifnull(taster_name,taster_twitter_handle)
                        from reviews
                        where ifnull(taster_name,taster_twitter_handle) is not null
                        group by ifnull(taster_name,taster_twitter_handle)
                ) as unique_reviewers;"""
cur.execute(sql)
rs = cur.fetchall()
df = pd.DataFrame(rs) #convert to dataframe
outfilepath='...unique_reviewers_output.csv'
df.columns=["unique_reviewers_count"]
df.to_csv(outfilepath, index=False)


#Step 3: Multi-Reviewers Query
#Write a script that ouputs users with five or more reviews.
print("Step 3: Multi-Reviewers Query")
sql = """select ifnull(taster_name,taster_twitter_handle) as multi_reviewers
                from reviews
                where ifnull(taster_name,taster_twitter_handle) is not null
                group by ifnull(taster_name,taster_twitter_handle)
                having count(*) >= 5;"""
cur.execute(sql)
rs = cur.fetchall()
df = pd.DataFrame(rs) #convert to dataframe
outfilepath='...multi_reviewers_output.csv'
df.columns=["multi_reviewers"]
df.to_csv(outfilepath, index=False)


#Step 4: Twitter Followers/Reviews
#Write a script that looks at the Twitter users and calculates a score for followers_count * number of reviews for that user.
print("Step 4: Twitter Followers/Reviews")
sql = """select 
	        taster_twitter_handle
                ,(ui.followers_count * r.review_count) as user_score
        from userinfo ui
        cross join
        (
                select 
                        taster_twitter_handle, 
                        count(*) as review_count
                from reviews r
                where taster_twitter_handle is not null
                group by taster_twitter_handle
        ) r
        where concat('@', ui.screen_name) = r.taster_twitter_handle
        order by user_score desc;"""
cur.execute(sql)
rs = cur.fetchall()
df = pd.DataFrame(rs) #convert to dataframe
outfilepath='...twitter_reviews_output.csv'
df.columns=['taster_twitter_handle', 'user_score']
df.to_csv(outfilepath, index=False)
